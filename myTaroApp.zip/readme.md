如果全局安装 taro 可直接执行
```
taro create --name [文件名称]
```
如果只在项目依赖中安装 taro
```
npx taro create --name [文件名称]
```
